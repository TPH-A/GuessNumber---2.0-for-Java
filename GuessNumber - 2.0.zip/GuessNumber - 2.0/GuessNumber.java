import java.util.*;

public class GuessNumber {
    public static void main(String[] args) {
        System.out.println("\n----------------------------Guess number range:100----------------------------\n");
        Random id = new Random();
        int num = id.nextInt(100);
        Scanner input = new Scanner(System.in);
        int times = 0;
        int maxtimes = 0;
        System.out.println("\n(Input 1 2 3 4 5)Choose difficulty:(1.easy,2.nomal,3.ordinary,4.hard,5.limit)");
        int choose = input.nextInt();
        switch (choose) {
            case 1:
                maxtimes = 30;
                break;
            case 2:
                maxtimes = 20;
                break;
            case 3:
                maxtimes = 15;
                break;
            case 4:
                maxtimes = 10;
                break;
            case 5:
                maxtimes = 5;
                break;
            default:
                System.out.println("\nWrong choose!Closing program!\n");
                System.exit(0);
            }
        long stime = System.currentTimeMillis();
        while (true) {
            System.out.println("\nEnter a number:");
            int guess = input.nextInt();
            if (guess >= num) {
                System.out.println("\nThe number is bigger!\n");
                times++;
            }
            if (guess <= num) {
                System.out.println("\nThe number is smaller!\n");
                times++;
            }
            if (guess == num) {
                System.out.println("\nYou are great!The number is " + num + ".\n");
                long etime = System.currentTimeMillis();
                double mtime = (etime - stime) / 1000;
                System.out.println("\nYou are use:" + mtime + "s and " + times + " times!\n");
                break;
            }
            if (times >= maxtimes) {
                System.out.println("No times!\n");
                break;
            }
        }
    }
}